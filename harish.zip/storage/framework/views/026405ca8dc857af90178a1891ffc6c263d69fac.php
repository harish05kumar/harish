<?php $__env->startSection('content'); ?>
<div class="login">
	<form action="<?php echo e(url('/verify')); ?>">
	<div class="container">
		<div class="name">
            <input class="form-control" type="email" name="email" placeholder="Email Address" class="<?php if ($errors->has('Email Address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Email Address'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <div class="form-control alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>

        <div class="name">
            <input class="form-control" type="password" name="password" placeholder="Password" class="<?php if ($errors->has('Password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
            <div class="form-control alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
		
	</div>
	<div class="button">
        <input type="submit" class="btn-group" name="">
        </div>
    </form>
	
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\harish\resources\views/login.blade.php ENDPATH**/ ?>