<?php $__env->startSection('content'); ?>
<table class="table">
    <thead>
      <tr>
      	<th>id</th>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Email</th>
      </tr>
    </thead>
    <tbody>
    	<?php if(count($datas)): ?>
        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($data->id); ?></td>
        <td><?php echo e($data->fname); ?></td>
        <td><?php echo e($data->lname); ?></td>
        <td><?php echo e($data->email); ?></td>
      </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php endif; ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\harish\resources\views/dashboard.blade.php ENDPATH**/ ?>