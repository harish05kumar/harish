<?php $__env->startSection('content'); ?>
<div class="register">
    <form action="<?php echo e(url('/register')); ?>">
    <div class="container">
        <?php echo e(csrf_field()); ?>

        <div class="name">
            <input class="form-control" type="text" name="fname" placeholder="First Name" class="<?php if ($errors->has('First Name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('First Name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
            <?php if ($errors->has('fname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fname'); ?>
            <div class="form-control alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="name">
            <input class="form-control" type="text" name="lname" placeholder="Last name" class="<?php if ($errors->has('Last name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Last name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
            <?php if ($errors->has('lname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lname'); ?>
            <div class="form-control alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="name">
            <input class="form-control" type="email" name="email" placeholder="Email Address" class="<?php if ($errors->has('Email Address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Email Address'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <div class="form-control alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="name">
            <input class="form-control" type="password" name="password" placeholder="Password" class="<?php if ($errors->has('Password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
            <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
            <div class="form-control alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        <div class="name">
            <input class="form-control" type="password" name="con_password" placeholder="Confirm Password" class="<?php if ($errors->has('Confirm Password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('Confirm Password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
            <?php if ($errors->has('con_password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('con_password'); ?>
            <div class="form-control alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
        </div>
        
    </div>
    <div class="button">
        <input type="submit" class="btn-group" name="">
        <a href="<?php echo e(url('/login')); ?>" class="btn-group" style="padding: 4px; border: 1px solid green; background:green; color: #ffff; border-radius: 3px; text-decoration: none;">Login</a>
        </div>
        </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\harish\resources\views/welcome.blade.php ENDPATH**/ ?>