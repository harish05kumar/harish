<?php $__env->startSection('content'); ?>
<div class="register">
    <form action="<?php echo e(url('/register')); ?>">
    <div class="container">
        <?php echo e(csrf_field()); ?>

        <div class="name">
            <input class="form-control" type="text" name="firstname" placeholder="First Name">
        </div>
        <div class="name">
            <input class="form-control" type="text" name="lastname" placeholder="Lastname">
        </div>
        <div class="name">
            <input class="form-control" type="email" name="email" placeholder="Email Address">
        </div>
        <div class="name">
            <input class="form-control" type="password" name="password" placeholder="Password">
        </div>
        <div class="name">
            <input class="form-control" type="password" name="password" placeholder="Confirm Password">
        </div>
        
    </div>
    <div class="button">
        <input type="submit" class="btn-group" name="">
        </div>
        </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\harish\resources\views/welcome.blade.php ENDPATH**/ ?>